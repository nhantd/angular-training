(function() {
  'use strict';

  angular
    .module('starwars')
    .controller('Films', Films);

    function Films(datafactory) {
      var vm = this;

      datafactory.getAllFilms()
        .then(function(data) {
          vm.films = data;
        });
    }

    Films.$inject = ['datafactory'];
    
})();

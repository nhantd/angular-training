(function() {
  'use strict';

  angular
    .module('starwars')
    .controller('Film', Film);

    function Film($routeParams, datafactory) {
      var vm = this;
      vm.episode = $routeParams.episode;
      vm.film = {};

      datafactory.getOneFilm(vm.episode)
        .then(function(data) {
          vm.film = data;
      });
    }

    Film.$inject = ['$routeParams', 'datafactory'];

})();
